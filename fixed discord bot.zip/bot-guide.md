# 🏴‍☠️ Sailing Kingdom Bot — Наръчник / User Guide

---

## 🇧🇬 БЪЛГАРСКИ

### 🚀 Първи стъпки — Настройка на нов сървър

**1. Включи Developer Mode**
Settings → Advanced → Developer Mode → десен клик на канал/роля → **Copy ID**

**2. Основна конфигурация (само Админ):**
```
!setconfig level_up_channel   <id>
!setconfig log_channel        <id>
!setconfig stats_channel      <id>
!setconfig admin_log_channel  <id>
!setconfig welcome_channel    <id>
!setconfig belly_rush_channel <id>
!setconfig reminders_channel  <id>
!setconfig translator_channel <id>
!setconfig bot_status_channel <id>
!setconfig rookies_role       <id>
!setconfig player_role        <id>
```
Провери с `!getconfig`.

---

### ⚔️ Mania — Настройка и употреба

**Добавяне на гилдия:**
```
!mania-addguild ts @ThousandSunny #mania-strategy #general
```
- `ts` — ключ (ти избираш, каквото искаш)
- `@ThousandSunny` — ролята на гилдията
- `#mania-strategy` — каналът където се пише командата и се гласува
- `#general` — каналът където всички виждат известието с линк

**Колкото гилдии искаш:**
```
!mania-addguild ts  @ThousandSunny  #mania-ts      #general
!mania-addguild ms  @MarineShip     #mania-ms      #general
!mania-addguild gs  @GoatShip       #mania-gs      #announcements
```

**Управление:**
```
!mania-guilds              ← показва всички гилдии с каналите им
!mania-removeguild ts      ← маха гилдия
```

**Пускане на план:**
```
mania-plan ts          ← план за Thousand Sunny
mania-plan ms          ← план за Marine Ship
mania-plan all         ← план за всички гилдии наведнъж
```
Ботът публикува плана с ✅ ❌ ⏳ в `#mania-strategy` и изпраща известие с линк в `#general`.

**Проверка кой е гласувал:**
```
mania-list ts          ← показва потвърдени, отказали, пингва липсващите
```
Известието за липсващите се изпраща и в `#general`.

**DM на незагласувалите:**
```
mania-dm ts
```

**Стратегия:**
```
mania-strategy
Kronos - @Luffy @Zoro
Hydra - @Nami @Sanji
Cerberus - @Robin
```
Всеки ред = един бос. Разделяй с тире `-`.

---

### 🚢 Belly Rush — Настройка на кораби

```
!ship-add Sunny ☀️ @mugi-role      ← добавя кораб
!ship-add Marine ⚓ @mari-role
!ship-add Goat 🐐 @goat-role

!ship-list                          ← всички кораби и екипажи
!ship-remove Sunny                  ← маха кораб
```

**Капитани (никога не се ресетват):**
```
!ship-captain @Luffy Sunny         ← задава капитан
!ship-uncaptain @Luffy             ← маха капитан
```

**Постоянен екипаж (потребителят сам заявява):**
```
!want Sunny                        ← постоянно място, не се ресетва
```

**Ръчен старт на панела:**
```
!setup
```
Автоматично се пуска всеки **вторник и петък в 10:00**.

---

### 🎖️ Нива и XP

```
!rank       ← твоето ниво и прогрес (изчезва след 60 сек)
!top        ← Топ 10 най-активни (само Админ)
!sync       ← ръчно запазване в базата (само Админ)
```
Пиши в сървъра → печелиш XP. Снимки = бонус XP. Спам = намален XP + предупреждения (3 → мут 10 мин).

---

### 💰 Bounty

```
!wanted              ← твоят Wanted плакат
!wanted @user        ← Wanted плакат на друг
!setbounty @user 500000000   ← задава bounty (Мод/Админ)
!resetbounty @user           ← нулира до ฿0 (Мод/Админ)
```

---

### ⚔️ Герои (само в #unit-build)

```
!hero-list              ← всички герои
!hero mihawk            ← билд на Mihawk
!hero luffy-cultiv1     ← Culti V1 вариант
```

---

### ⏰ Напомняния

```
!remind 0 21 * * * Raid!   ← всеки ден в 21:00
!reminders                  ← твоите напомняния
!allreminders               ← всички напомняния
!delete <id>                ← изтрива напомняне
!cron                       ← наръчник за cron формата
```

---

### 🛂 Верификация на нови членове

1. Нов потребител → автоматично получава **Rookie** роля
2. Вижда Welcome съобщение с бутон **"Nickname"**
3. Въвежда nickname с гилдиен таг
4. Получава **Player** роля и достъп

---

### 🌐 AI Преводач (в #ai-translator)

- Пишеш на **всякакъв език** → превод на английски
- Отговаряш на чужденец на английски → превод обратно на неговия език

---

### 🧹 Модерация

```
!clear 50                  ← трие последните 50 съобщения
!say Ahoy!                 ← ботът изпраща (командата се трие)
!sendto #канал Ahoy!       ← изпраща в конкретен канал
!addrole @user Роля        ← дава роля
!removerole @user Роля     ← маха роля
!addroleallts @роля        ← дава роля на всички с тага ᐪˢ☠️
!addroleallgm @роля        ← дава роля на всички с тага ᴳᴹ☠️
```

---
---

## 🇬🇧 ENGLISH

### 🚀 Getting Started — New Server Setup

**1. Enable Developer Mode**
Settings → Advanced → Developer Mode → right-click channel/role → **Copy ID**

**2. Basic configuration (Admin only):**
```
!setconfig level_up_channel   <id>
!setconfig log_channel        <id>
!setconfig stats_channel      <id>
!setconfig admin_log_channel  <id>
!setconfig welcome_channel    <id>
!setconfig belly_rush_channel <id>
!setconfig reminders_channel  <id>
!setconfig translator_channel <id>
!setconfig bot_status_channel <id>
!setconfig rookies_role       <id>
!setconfig player_role        <id>
```
Verify with `!getconfig`.

---

### ⚔️ Mania — Setup & Usage

**Add a guild:**
```
!mania-addguild ts @ThousandSunny #mania-strategy #general
```
- `ts` — key (you choose whatever you want)
- `@ThousandSunny` — the guild's role
- `#mania-strategy` — the channel where commands are typed and voting happens
- `#general` — the channel where everyone sees the notification with the link

**Add as many guilds as you want:**
```
!mania-addguild ts  @ThousandSunny  #mania-ts   #general
!mania-addguild ms  @MarineShip     #mania-ms   #general
!mania-addguild gs  @GoatShip       #mania-gs   #announcements
```

**Management:**
```
!mania-guilds              ← list all guilds with their channels
!mania-removeguild ts      ← remove a guild
```

**Start a plan:**
```
mania-plan ts          ← plan for Thousand Sunny
mania-plan ms          ← plan for Marine Ship
mania-plan all         ← plan for ALL guilds at once
```
Bot posts the plan with ✅ ❌ ⏳ in `#mania-strategy` and sends a notification with a link to `#general`.

**Check who voted:**
```
mania-list ts          ← shows confirmed, declined, pings missing members
```
The missing members notification is also sent to `#general`.

**DM non-voters:**
```
mania-dm ts
```

**Post the strategy:**
```
mania-strategy
Kronos - @Luffy @Zoro
Hydra - @Nami @Sanji
Cerberus - @Robin
```
Each line = one boss. Separate boss and players with a dash `-`.

---

### 🚢 Belly Rush — Ship Setup

```
!ship-add Sunny ☀️ @mugi-role      ← add a ship
!ship-add Marine ⚓ @mari-role
!ship-add Goat 🐐 @goat-role

!ship-list                          ← view all ships and crews
!ship-remove Sunny                  ← remove a ship
```

**Captains (never get reset):**
```
!ship-captain @Luffy Sunny         ← set permanent captain
!ship-uncaptain @Luffy             ← remove captain status
```

**Permanent crew (users request it themselves):**
```
!want Sunny                        ← permanent spot, never reset
```

**Manually trigger the panel:**
```
!setup
```
Auto-posts every **Tuesday and Friday at 10:00**.

---

### 🎖️ Leveling

```
!rank       ← your level and progress bar (auto-deletes after 60s)
!top        ← Top 10 most active (Admin only)
!sync       ← manually flush XP to database (Admin only)
```
Chat → earn XP. Images = bonus XP. Spamming = reduced XP + warnings (3 → 10 min mute).

---

### 💰 Bounty

```
!wanted              ← your Wanted poster
!wanted @user        ← someone else's Wanted poster
!setbounty @user 500000000   ← set bounty (Mod/Admin)
!resetbounty @user           ← reset to ฿0 (Mod/Admin)
```

---

### ⚔️ Heroes (only in #unit-build)

```
!hero-list              ← all available heroes
!hero mihawk            ← Mihawk's full build
!hero luffy-cultiv1     ← Luffy Culti V1 variant
```

---

### ⏰ Reminders

```
!remind 0 21 * * * Raid!   ← every day at 21:00
!reminders                  ← your reminders
!allreminders               ← all reminders
!delete <id>                ← delete a reminder
!cron                       ← cron format guide
```

---

### 🛂 New Member Verification

1. New user joins → automatically gets **Rookie** role
2. Sees a Welcome message with a **"Nickname"** button
3. Types nickname with guild tag
4. Gets **Player** role and full server access

---

### 🌐 AI Translator (in #ai-translator)

- Write in **any language** → translated to English
- Reply to a non-English user in English → translates back to their language

---

### 🧹 Moderation

```
!clear 50                  ← delete last 50 messages
!say Ahoy!                 ← bot sends the message (command is deleted)
!sendto #channel Ahoy!     ← send to a specific channel
!addrole @user Role        ← give a role
!removerole @user Role     ← remove a role
!addroleallts @role        ← give role to everyone with ᐪˢ☠️ tag
!addroleallgm @role        ← give role to everyone with ᴳᴹ☠️ tag
```

---

> 📌 Every server is independent. Configs, guilds, ships and captains are all stored separately per server.
